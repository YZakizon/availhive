# AGENTS.md

## Project

This repository is for an appointment commitment SaaS for service businesses.

The product helps businesses make appointments real before the slot is confirmed:

```text
policy accepted + deposit paid + consent captured + reminders scheduled
```

The app should support multiple appointment-based verticals, including:

- tattoo artists and tattoo studios
- nail salons
- spas
- hair salons
- barbers
- med spas
- lash/brow providers
- massage therapists
- tutors
- photographers
- independent service providers

Do not build the product as tattoo-only. Tattoo can be one template, not the whole app.

The MVP is not a generic Calendly clone and not an Eventbrite/Ticket Tailor clone. The MVP is a deposit-secured appointment workflow for service businesses.

---

## Stack

Use this stack unless the human owner explicitly changes it:

```text
Framework: Next.js App Router
Language: TypeScript
UI: Tailwind CSS + shadcn/ui
Database: PostgreSQL
ORM: Prisma
Cache/Queue: Redis + BullMQ
Payments: Stripe Connect + Stripe Checkout
SMS: Twilio Programmable Messaging
Email: Twilio SendGrid
Validation: Zod
Forms: React Hook Form + shadcn/ui Form
Testing: Vitest and/or Playwright where appropriate
```

Do not add Go, Express, NestJS, tRPC, Drizzle, Supabase Auth, Clerk, or another major framework unless requested by the human owner.

---

## Core Product Workflow

The core appointment workflow is:

```text
Business creates booking hold
→ SaaS creates secure confirmation link
→ Business shares link with client
→ Client opens link
→ Client reviews appointment
→ Client accepts cancellation/no-show policy
→ Client opts into SMS/email reminders if desired
→ Client pays deposit through Stripe
→ Stripe webhook confirms payment
→ Booking hold becomes confirmed appointment
→ Email/SMS reminders are scheduled
→ Appointment is completed, cancelled, or marked no-show
```

Important: a phone number typed by the business is contact information only. It is not SMS consent. SMS consent must be captured directly through the customer-facing confirmation flow or another explicit opt-in flow.

---

## Main Product Objects

Use these domain concepts consistently:

- `Business`: SaaS customer account/business profile.
- `User`: staff/admin login user.
- `Provider`: person who performs appointments, such as stylist, nail tech, barber, artist, tutor, photographer.
- `Service`: bookable service with duration, price, deposit, and policy defaults.
- `PolicyTemplate`: reusable cancellation/no-show policy.
- `Customer`: end client who books with the business.
- `BookingHold`: pending appointment slot awaiting client confirmation/deposit.
- `Appointment`: confirmed appointment after required policy/payment steps are complete.
- `PolicyAcceptance`: immutable record/snapshot of policy accepted by customer.
- `SmsConsent`: explicit permission to send appointment-related SMS.
- `EmailConsent`: optional email consent or transactional email preference if implemented.
- `Payment`: internal ledger row for deposits, refunds, no-show fees, and payout references.
- `MessageLog`: SMS/email delivery and template log.
- `WaitlistEntry`: future feature for cancellation refill.
- `AuditLog`: important status/payment/consent actions.

---

## Required Status State Machines

### Booking Hold

```text
HOLD_CREATED
AWAITING_CONFIRMATION
AWAITING_PAYMENT
CONFIRMED
EXPIRED
CANCELLED
```

### Appointment

```text
CONFIRMED
CONFIRMATION_REQUESTED
AT_RISK
COMPLETED
CANCELLED
NO_SHOW
```

### Payment

```text
PENDING
PROCESSING
SUCCEEDED
FAILED
REFUNDED
PARTIALLY_REFUNDED
DISPUTED
FORFEITED
```

### Message

```text
QUEUED
SENT
DELIVERED
FAILED
SKIPPED_NO_CONSENT
OPTED_OUT
```

Do not invent new status names without updating the schema, types, tests, and related docs.

---

## Non-Negotiable Product Rules

1. Never send SMS unless an active `SmsConsent` exists.
2. A pasted phone number is not SMS consent.
3. Do not mark a deposit-required booking as confirmed based on a client redirect page.
4. Stripe webhooks are the source of truth for payment success.
5. Stripe webhook handlers must verify signatures.
6. Stripe webhook handlers must be idempotent.
7. Store a snapshot of the accepted policy text, not only a policy ID.
8. Use secure random tokens for public confirmation URLs.
9. Public confirmation URLs must not expose sequential numeric IDs.
10. Use database transactions for payment + booking/appointment state transitions.
11. Do not expose platform secrets to client components.
12. Do not build native mobile apps in the MVP.
13. Do not build full ticketing/event platform features in the MVP.
14. Keep appointment mode first; event/class/ticketing mode can be added later.

---

## Multi-Agent Workflow

When using Codex CLI with multiple agents, use separate Git worktrees. Each agent should own a narrow slice of the app.

Recommended branches/worktrees:

```text
feat/ui-dashboard
feat/prisma-schema
feat/auth-business-setup
feat/booking-holds
feat/public-confirmation-page
feat/stripe-deposits
feat/twilio-sendgrid-messaging
feat/appointment-status-actions
feat/integration-qa
```

Each agent must:

1. Read `AGENTS.md`, `CODEX_PLAN.md`, and `CODEX_RULES.md` before editing.
2. Work only on the scoped task.
3. Avoid unrelated refactors.
4. Keep diffs reviewable.
5. Run validation commands before finishing.
6. Summarize changed files, migrations, env var changes, and follow-up risks.

---

## Agent Task Boundaries

### UI Dashboard Agent

Allowed:

- dashboard shell
- sidebar navigation
- KPI cards
- mock booking-hold list
- mock create-booking-hold UI
- services/policies UI
- customers UI
- payments UI
- settings UI
- shadcn/ui components

Not allowed:

- Stripe integration
- Twilio integration
- database mutations unless explicitly asked
- auth architecture changes

### Prisma Schema Agent

Allowed:

- `prisma/schema.prisma`
- migrations
- seed data
- Prisma client helper
- database enums and indexes

Not allowed:

- UI pages
- Stripe/Twilio implementation
- major auth provider decisions unless asked

### Booking Hold Agent

Allowed:

- booking hold create/list/detail
- secure confirmation token generation
- Zod validation
- status transitions
- expiration fields/jobs stubs

Not allowed:

- Stripe payment success logic unless Stripe task is assigned
- SMS sending
- large UI redesigns

### Public Confirmation Page Agent

Allowed:

- `/confirm/[token]` customer page
- customer contact capture
- policy acceptance
- SMS/email opt-in capture
- start deposit checkout placeholder if Stripe is not implemented

Not allowed:

- marking payment as successful without Stripe webhook
- sending SMS without consent

### Stripe Agent

Allowed:

- Stripe client wrapper
- Stripe Connect onboarding links
- Checkout Session creation
- webhook endpoint
- idempotent webhook fulfillment
- payment ledger updates
- appointment confirmation after verified payment

Not allowed:

- client-side payment success state changes
- unverified webhook logic
- storing raw card data

### Messaging Agent

Allowed:

- Twilio SMS wrapper
- SendGrid email wrapper
- `MessageLog`
- BullMQ reminder queues/workers
- STOP/opt-out webhook
- consent guard utilities

Not allowed:

- marketing SMS
- SMS sending without active consent
- broad provider/library swaps

### Integration QA Agent

Allowed:

- fix broken imports
- fix type errors
- align enum names
- fix tests
- identify security/compliance risks
- add missing env validation

Not allowed:

- new product features
- unrelated refactors

---

## Preferred Commands

Use project scripts if they exist. If not, add them.

```bash
npm run lint
npm run typecheck
npm test
npx prisma validate
npx prisma format
```

For database changes:

```bash
npx prisma migrate dev
npx prisma generate
```

For UI component additions:

```bash
npx shadcn@latest add button card input label textarea select checkbox form table badge dialog dropdown-menu tabs separator sheet calendar popover toast
```

Do not run destructive commands like `rm -rf`, `prisma migrate reset`, `git reset --hard`, or database drops unless the human owner explicitly approves.

---

## Coding Style

- Use strict TypeScript.
- Use clear domain names.
- Prefer server components for read-only pages.
- Use client components only for interactive forms, dialogs, and stateful UI.
- Validate all external inputs with Zod.
- Keep business authorization checks server-side.
- Use Prisma transactions for multi-row state transitions.
- Use typed enums instead of raw string literals where possible.
- Keep public token routes minimal and secure.
- Keep UI mobile-first for customer-facing pages.
- Keep admin dashboard responsive but desktop-friendly.

---

## Security and Compliance Priorities

Pay extra attention to:

- multi-tenant access control by `businessId`
- Stripe webhook signature verification
- Stripe event idempotency
- Twilio webhook validation if feasible
- SMS consent enforcement
- STOP/opt-out handling
- secrets never exposed to the browser
- rate limiting public token endpoints
- token expiration
- audit logs for policy/payment/consent/status changes
- no raw card data storage

---

## Definition of Done

A Codex task is done only when:

1. The scoped feature is implemented.
2. Code is typed and formatted.
3. Lint/typecheck pass or failures are clearly reported.
4. Tests are added for important business logic where reasonable.
5. No unrelated features were added.
6. Security-sensitive logic is not bypassed.
7. The final response includes:
   - changed files
   - commands run
   - remaining risks
   - any env vars or migrations added


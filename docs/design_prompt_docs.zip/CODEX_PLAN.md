# CODEX_PLAN.md

# Appointment Commitment SaaS — Next.js/TypeScript Technical Plan

## 0. Product Summary

Build a SaaS platform that helps appointment-based service businesses secure bookings before they become real appointments.

The app is vertical-neutral and should support businesses such as:

- tattoo artists and tattoo studios
- nail salons
- spas
- hair salons
- barbers
- med spas
- lash/brow providers
- massage therapists
- tutors
- photographers
- independent service providers

Core promise:

> Make every appointment real before it touches the calendar: policy accepted, deposit paid, consent captured, reminders scheduled.

This is not primarily an event-ticketing product and not just a Calendly clone. The MVP is an appointment commitment layer.

---

## 1. Updated Tech Stack

### Frontend + Backend

Use a single full-stack Next.js app.

- Next.js App Router
- TypeScript
- Tailwind CSS
- shadcn/ui
- React Server Components by default
- Client Components only for interactive UI
- Server Actions for internal form mutations
- Route Handlers for public API endpoints, Stripe webhooks, Twilio webhooks, and SendGrid webhooks

### Data

- PostgreSQL as the source of truth
- Prisma ORM for schema, migrations, and typed queries
- Redis for caching, rate limits, idempotency locks, and background jobs
- BullMQ for scheduled jobs and workers

### Integrations

- Stripe Connect + Stripe Checkout for deposits, platform fees, refunds, and payouts
- Twilio Programmable Messaging for SMS
- Twilio SendGrid for email
- Optional later: Google Calendar / Outlook Calendar sync

### Deployment

Recommended MVP deployment:

- Next.js app: Vercel, Railway, Render, Fly.io, or AWS
- Worker process: Railway, Render, Fly.io, ECS, or any long-running Node runtime
- Postgres: Supabase, Neon, Railway, Render, AWS RDS, or Crunchy Bridge
- Redis: Upstash, Railway Redis, Redis Cloud, or AWS ElastiCache

Important: do not run the BullMQ worker inside short-lived serverless request handlers. The worker should be a separate long-running Node process.

---

## 2. Why Remove Go From MVP

The earlier plan used React + Go. The new plan should remove Go for the MVP.

Reason:

- Next.js + TypeScript is faster for building the product end-to-end.
- The same language can be used for frontend, backend, validation, job payloads, and shared types.
- shadcn/ui accelerates dashboard development.
- BullMQ gives a TypeScript-native background job system on Redis.
- Go can be added later only if a specific bottleneck appears.

Optional later Go services:

- high-volume messaging service
- calendar sync engine
- analytics aggregation service
- webhook ingestion service
- AI/intake extraction service

Do not start with Go unless the project already has a Go-heavy engineering team.

---

## 3. Main User Roles

### Platform Admin

Internal team/admin account.

Can:

- view businesses
- monitor payment status
- monitor failed jobs
- handle support cases
- view compliance logs
- disable risky accounts

### Business Owner

The paying SaaS customer.

Can:

- create business profile
- connect Stripe
- create services
- set deposit and cancellation policies
- create booking holds
- manage customers
- manage providers/staff
- view payments
- view dashboard analytics

### Provider / Staff

A staff member who performs services.

Examples:

- stylist
- nail tech
- massage therapist
- tattoo artist
- esthetician
- barber
- tutor

Can:

- view assigned appointments
- create booking holds if allowed
- mark appointment complete/no-show
- view limited customer details

### Customer / Client

The end customer booking the appointment.

Can:

- open a confirmation link
- review appointment details
- accept policy
- opt into SMS/email reminders
- pay deposit
- cancel/reschedule through link
- join waitlist later

Customers do not need accounts for MVP.

---

## 4. Core Concepts

### Booking Hold

A temporary appointment offer created by the business.

A hold is not a confirmed appointment.

It becomes real only when the client:

1. accepts the policy
2. provides/validates contact information
3. consents to communications if SMS/email reminders are enabled
4. pays deposit or completes required payment/card setup

Statuses:

- `HOLD_CREATED`
- `AWAITING_CLIENT_CONFIRMATION`
- `POLICY_ACCEPTED`
- `AWAITING_DEPOSIT`
- `CONFIRMED`
- `EXPIRED`
- `CANCELLED`

### Appointment

A confirmed booking.

Statuses:

- `CONFIRMED`
- `CONFIRMATION_REQUESTED`
- `AT_RISK`
- `COMPLETED`
- `CANCELLED`
- `LATE_CANCELLED`
- `NO_SHOW`

### Policy Acceptance

A timestamped record proving the customer accepted the cancellation/no-show policy.

Must store:

- policy text snapshot
- policy version
- timestamp
- IP address
- user agent
- booking hold ID
- customer ID

### SMS Consent

A phone number is not consent.

Store consent separately from contact info.

Must store:

- phone number
- business ID
- customer ID
- consent scope
- consent text snapshot
- consent source
- timestamp
- revoked timestamp

### Deposit

A payment collected through Stripe Checkout before confirmation.

MVP should support:

- fixed deposit amount
- percent deposit amount
- full prepayment
- no deposit

Card-on-file can be added later.

---

## 5. MVP Scope

### Must Build

1. Business signup/login
2. Business profile
3. Stripe Connect onboarding
4. Service creation
5. Policy template creation
6. Provider/staff creation
7. Create booking hold
8. Customer confirmation/deposit page
9. Stripe Checkout deposit payment
10. Stripe webhook fulfillment
11. Policy acceptance record
12. SMS/email opt-in record
13. Email confirmation via SendGrid
14. SMS confirmation/reminder via Twilio after consent
15. Reminder jobs with BullMQ
16. Appointment status management
17. No-show/late-cancel recording
18. Customer list and customer detail
19. Basic payments ledger
20. Dashboard KPIs

### Should Build Soon After MVP

1. Waitlist and refill
2. Refund workflow
3. Customer reschedule flow
4. Calendar sync
5. Multi-location support
6. More detailed analytics
7. Intake forms by industry template
8. Email/SMS template customization

### Do Not Build First

1. Native iOS/Android apps
2. Full event ticketing
3. AI receptionist
4. Instagram DM integration
5. Complex calendar availability engine
6. Card-on-file no-show charging
7. White-label domains
8. Marketplace discovery

---

## 6. Recommended Repository Structure

Use a single TypeScript monorepo-style Next.js repo.

```txt
appointment-secure/
  app/
    (marketing)/
      page.tsx
      pricing/page.tsx
      faq/page.tsx
    (auth)/
      sign-in/page.tsx
      sign-up/page.tsx
    (dashboard)/
      layout.tsx
      dashboard/page.tsx
      booking-holds/
        page.tsx
        new/page.tsx
        [id]/page.tsx
      bookings/page.tsx
      calendar/page.tsx
      services/page.tsx
      policies/page.tsx
      providers/page.tsx
      customers/page.tsx
      customers/[id]/page.tsx
      payments/page.tsx
      waitlist/page.tsx
      analytics/page.tsx
      settings/page.tsx
    confirm/
      [token]/page.tsx
    pay/
      success/page.tsx
      cancel/page.tsx
    api/
      booking-holds/route.ts
      booking-holds/[id]/route.ts
      booking-holds/[id]/checkout/route.ts
      webhooks/
        stripe/route.ts
        twilio/route.ts
        sendgrid/route.ts
      health/route.ts
  components/
    ui/                         # shadcn/ui generated components
    marketing/
    dashboard/
    booking-holds/
    customers/
    payments/
    shared/
  lib/
    auth.ts
    db.ts
    env.ts
    stripe.ts
    twilio.ts
    sendgrid.ts
    redis.ts
    queues.ts
    validators.ts
    money.ts
    dates.ts
    consent.ts
    policies.ts
    errors.ts
  server/
    actions/
      booking-holds.ts
      services.ts
      policies.ts
      providers.ts
      settings.ts
    services/
      booking-hold-service.ts
      appointment-service.ts
      payment-service.ts
      notification-service.ts
      consent-service.ts
      policy-service.ts
      waitlist-service.ts
      analytics-service.ts
  prisma/
    schema.prisma
    migrations/
    seed.ts
  worker/
    index.ts
    processors/
      reminders.ts
      hold-expiration.ts
      waitlist-refill.ts
      email.ts
      sms.ts
  public/
  middleware.ts
  package.json
  tsconfig.json
  tailwind.config.ts
  next.config.ts
  .env.example
```

---

## 7. Initial Setup Commands

Use pnpm if possible.

```bash
pnpm create next-app@latest appointment-secure \
  --typescript \
  --tailwind \
  --eslint \
  --app \
  --src-dir=false \
  --import-alias "@/*"

cd appointment-secure
```

Install shadcn/ui:

```bash
pnpm dlx shadcn@latest init
```

Add common shadcn/ui components:

```bash
pnpm dlx shadcn@latest add button card input label textarea select checkbox dialog dropdown-menu tabs table badge alert form sheet separator calendar popover command toast sonner
```

Install app dependencies:

```bash
pnpm add zod react-hook-form @hookform/resolvers
pnpm add prisma @prisma/client
pnpm add stripe @stripe/stripe-js
pnpm add twilio @sendgrid/mail
pnpm add bullmq ioredis
pnpm add date-fns nanoid
pnpm add lucide-react class-variance-authority clsx tailwind-merge
pnpm add bcryptjs jose
```

Install dev dependencies:

```bash
pnpm add -D tsx dotenv prettier eslint-config-prettier
```

Initialize Prisma:

```bash
pnpm prisma init
```

---

## 8. Environment Variables

Create `.env.example`:

```bash
# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
APP_ENV=development

# Auth
AUTH_SECRET=replace_me

# Database
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/appointment_secure

# Redis
REDIS_URL=redis://localhost:6379

# Stripe
STRIPE_SECRET_KEY=sk_test_replace_me
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_replace_me
STRIPE_WEBHOOK_SECRET=whsec_replace_me
STRIPE_CONNECT_CLIENT_ID=ca_replace_me
PLATFORM_APPLICATION_FEE_BPS=100

# Twilio SMS
TWILIO_ACCOUNT_SID=AC_replace_me
TWILIO_AUTH_TOKEN=replace_me
TWILIO_MESSAGING_SERVICE_SID=MG_replace_me
TWILIO_WEBHOOK_AUTH_TOKEN=replace_me

# SendGrid Email
SENDGRID_API_KEY=SG_replace_me
SENDGRID_FROM_EMAIL=no-reply@yourdomain.com
SENDGRID_FROM_NAME=AppointmentSecure

# Security
ENCRYPTION_KEY=replace_with_32_byte_key
```

Never expose these to the browser:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `TWILIO_AUTH_TOKEN`
- `SENDGRID_API_KEY`
- `DATABASE_URL`
- `REDIS_URL`
- `ENCRYPTION_KEY`

---

## 9. Database Schema Draft

Use Prisma.

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum BusinessRole {
  OWNER
  ADMIN
  PROVIDER
  STAFF
}

enum BookingHoldStatus {
  HOLD_CREATED
  AWAITING_CLIENT_CONFIRMATION
  POLICY_ACCEPTED
  AWAITING_DEPOSIT
  CONFIRMED
  EXPIRED
  CANCELLED
}

enum AppointmentStatus {
  CONFIRMED
  CONFIRMATION_REQUESTED
  AT_RISK
  COMPLETED
  CANCELLED
  LATE_CANCELLED
  NO_SHOW
}

enum DepositStatus {
  NOT_REQUIRED
  PENDING
  PAID
  REFUNDED
  FORFEITED
  FAILED
}

enum PaymentType {
  DEPOSIT
  FULL_PAYMENT
  REFUND
  NO_SHOW_FEE
  PLATFORM_FEE
}

enum PaymentStatus {
  PENDING
  SUCCEEDED
  FAILED
  REFUNDED
  PARTIALLY_REFUNDED
}

enum ConsentScope {
  APPOINTMENT_UPDATES
  MARKETING
}

enum ReminderChannel {
  EMAIL
  SMS
}

model User {
  id           String   @id @default(cuid())
  email        String   @unique
  passwordHash String?
  name         String?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  memberships BusinessMember[]
}

model Business {
  id                       String   @id @default(cuid())
  name                     String
  slug                     String   @unique
  email                    String?
  phone                    String?
  addressLine1             String?
  addressLine2             String?
  city                     String?
  state                    String?
  postalCode               String?
  country                  String   @default("US")
  timezone                 String   @default("America/Los_Angeles")
  stripeConnectedAccountId String?
  stripeChargesEnabled     Boolean  @default(false)
  stripePayoutsEnabled     Boolean  @default(false)
  createdAt                DateTime @default(now())
  updatedAt                DateTime @updatedAt

  members          BusinessMember[]
  services         Service[]
  policies         PolicyTemplate[]
  providers        Provider[]
  customers        Customer[]
  bookingHolds     BookingHold[]
  appointments     Appointment[]
  payments         Payment[]
  smsConsents      SmsConsent[]
  policyAcceptances PolicyAcceptance[]
}

model BusinessMember {
  id         String       @id @default(cuid())
  businessId String
  userId     String
  role       BusinessRole @default(STAFF)
  createdAt  DateTime     @default(now())

  business Business @relation(fields: [businessId], references: [id], onDelete: Cascade)
  user     User     @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([businessId, userId])
  @@index([userId])
}

model Provider {
  id          String   @id @default(cuid())
  businessId  String
  name        String
  email       String?
  phone       String?
  title       String?
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  business     Business       @relation(fields: [businessId], references: [id], onDelete: Cascade)
  services     ProviderService[]
  bookingHolds BookingHold[]
  appointments Appointment[]

  @@index([businessId])
}

model Service {
  id                       String   @id @default(cuid())
  businessId               String
  name                     String
  description              String?
  durationMinutes           Int
  priceCents               Int?
  depositRequired          Boolean  @default(true)
  depositAmountCents       Int?
  depositPercent           Int?
  defaultPolicyTemplateId  String?
  active                   Boolean  @default(true)
  createdAt                DateTime @default(now())
  updatedAt                DateTime @updatedAt

  business      Business          @relation(fields: [businessId], references: [id], onDelete: Cascade)
  providers     ProviderService[]
  bookingHolds  BookingHold[]
  appointments  Appointment[]

  @@index([businessId])
}

model ProviderService {
  providerId String
  serviceId  String

  provider Provider @relation(fields: [providerId], references: [id], onDelete: Cascade)
  service  Service  @relation(fields: [serviceId], references: [id], onDelete: Cascade)

  @@id([providerId, serviceId])
}

model PolicyTemplate {
  id                       String   @id @default(cuid())
  businessId                String
  name                     String
  body                     String
  version                  Int      @default(1)
  cancellationWindowHours   Int      @default(24)
  lateCancelAction          String   @default("KEEP_DEPOSIT")
  noShowAction              String   @default("KEEP_DEPOSIT")
  active                   Boolean  @default(true)
  createdAt                DateTime @default(now())
  updatedAt                DateTime @updatedAt

  business     Business      @relation(fields: [businessId], references: [id], onDelete: Cascade)
  bookingHolds BookingHold[]

  @@index([businessId])
}

model Customer {
  id              String   @id @default(cuid())
  businessId      String
  name            String
  email           String?
  phone           String?
  instagramHandle String?
  completedCount  Int      @default(0)
  noShowCount     Int      @default(0)
  lateCancelCount Int      @default(0)
  notes           String?
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  business          Business           @relation(fields: [businessId], references: [id], onDelete: Cascade)
  bookingHolds      BookingHold[]
  appointments      Appointment[]
  payments          Payment[]
  smsConsents       SmsConsent[]
  policyAcceptances PolicyAcceptance[]
  waitlistEntries   WaitlistEntry[]

  @@index([businessId])
  @@index([businessId, phone])
  @@index([businessId, email])
}

model BookingHold {
  id                   String            @id @default(cuid())
  businessId            String
  customerId            String?
  providerId            String?
  serviceId             String
  policyTemplateId      String?
  token                 String            @unique
  status                BookingHoldStatus @default(AWAITING_CLIENT_CONFIRMATION)
  clientName            String?
  clientEmail           String?
  clientPhone           String?
  clientInstagramHandle String?
  startTime             DateTime
  endTime               DateTime
  depositAmountCents    Int
  estimatedTotalCents   Int?
  notes                 String?
  expiresAt             DateTime?
  confirmedAt           DateTime?
  createdAt             DateTime          @default(now())
  updatedAt             DateTime          @updatedAt

  business       Business        @relation(fields: [businessId], references: [id], onDelete: Cascade)
  customer       Customer?       @relation(fields: [customerId], references: [id])
  provider       Provider?       @relation(fields: [providerId], references: [id])
  service        Service         @relation(fields: [serviceId], references: [id])
  policyTemplate PolicyTemplate? @relation(fields: [policyTemplateId], references: [id])
  appointment    Appointment?

  @@index([businessId, status])
  @@index([token])
}

model Appointment {
  id                  String            @id @default(cuid())
  businessId           String
  bookingHoldId        String?           @unique
  customerId           String
  providerId           String?
  serviceId            String
  status               AppointmentStatus @default(CONFIRMED)
  depositStatus        DepositStatus     @default(PENDING)
  startTime            DateTime
  endTime              DateTime
  confirmedAt          DateTime?
  cancelledAt          DateTime?
  completedAt          DateTime?
  noShowMarkedAt       DateTime?
  policyAcceptanceId   String?
  smsConsentId         String?
  stripeCheckoutSessionId String?
  stripePaymentIntentId   String?
  createdAt            DateTime @default(now())
  updatedAt            DateTime @updatedAt

  business         Business          @relation(fields: [businessId], references: [id], onDelete: Cascade)
  bookingHold      BookingHold?      @relation(fields: [bookingHoldId], references: [id])
  customer         Customer          @relation(fields: [customerId], references: [id])
  provider         Provider?         @relation(fields: [providerId], references: [id])
  service          Service           @relation(fields: [serviceId], references: [id])
  payments         Payment[]
  reminders        Reminder[]
  policyAcceptance PolicyAcceptance? @relation(fields: [policyAcceptanceId], references: [id])
  smsConsent       SmsConsent?       @relation(fields: [smsConsentId], references: [id])

  @@index([businessId, startTime])
  @@index([businessId, status])
  @@index([customerId])
}

model PolicyAcceptance {
  id             String   @id @default(cuid())
  businessId      String
  customerId      String
  appointmentId   String?
  bookingHoldId   String?
  policyName      String
  policyBody      String
  policyVersion   Int
  ipAddress       String?
  userAgent       String?
  acceptedAt      DateTime @default(now())

  business    Business      @relation(fields: [businessId], references: [id], onDelete: Cascade)
  customer    Customer      @relation(fields: [customerId], references: [id], onDelete: Cascade)
  appointment Appointment[]

  @@index([businessId, customerId])
}

model SmsConsent {
  id             String       @id @default(cuid())
  businessId      String
  customerId      String
  phone           String
  scope           ConsentScope @default(APPOINTMENT_UPDATES)
  consentText     String
  source          String
  consentedAt     DateTime     @default(now())
  revokedAt       DateTime?
  ipAddress       String?
  userAgent       String?

  business     Business      @relation(fields: [businessId], references: [id], onDelete: Cascade)
  customer     Customer      @relation(fields: [customerId], references: [id], onDelete: Cascade)
  appointments Appointment[]

  @@index([businessId, customerId])
  @@index([phone])
}

model Payment {
  id                      String        @id @default(cuid())
  businessId               String
  customerId               String?
  appointmentId            String?
  type                    PaymentType
  status                  PaymentStatus @default(PENDING)
  amountCents             Int
  currency                String        @default("usd")
  stripeCheckoutSessionId String?
  stripePaymentIntentId   String?
  stripeChargeId          String?
  stripeRefundId          String?
  metadata                Json?
  createdAt               DateTime      @default(now())
  updatedAt               DateTime      @updatedAt

  business    Business     @relation(fields: [businessId], references: [id], onDelete: Cascade)
  customer    Customer?    @relation(fields: [customerId], references: [id])
  appointment Appointment? @relation(fields: [appointmentId], references: [id])

  @@index([businessId, createdAt])
  @@index([stripePaymentIntentId])
}

model Reminder {
  id            String          @id @default(cuid())
  appointmentId String
  channel       ReminderChannel
  scheduledFor  DateTime
  sentAt        DateTime?
  status        String          @default("SCHEDULED")
  providerMessageId String?
  errorMessage  String?
  createdAt     DateTime        @default(now())

  appointment Appointment @relation(fields: [appointmentId], references: [id], onDelete: Cascade)

  @@index([appointmentId])
  @@index([scheduledFor])
}

model WaitlistEntry {
  id                  String   @id @default(cuid())
  businessId           String
  customerId           String
  serviceId            String?
  providerId           String?
  preferredStartAfter  DateTime?
  preferredStartBefore DateTime?
  status              String   @default("ACTIVE")
  offerToken          String?  @unique
  offerExpiresAt      DateTime?
  createdAt           DateTime @default(now())
  updatedAt           DateTime @updatedAt

  customer Customer @relation(fields: [customerId], references: [id], onDelete: Cascade)

  @@index([businessId, status])
}
```

Codex note: the schema above is a strong starting point. It may need minor relation cleanup during implementation, but the entity model and statuses should stay intact.

---

## 10. Authentication Plan

For MVP, choose one of these:

### Option A — Fastest

Use Clerk for auth.

Pros:

- fastest to ship
- handles password reset, social login, email verification, sessions
- good for SaaS dashboards

Cons:

- external dependency and monthly cost

### Option B — Fully owned

Use Auth.js or a custom email/password flow.

Pros:

- more control
- lower vendor dependency

Cons:

- slower to build safely

Recommended for MVP: Clerk if budget allows. If not, implement email/password auth with secure password hashing and HttpOnly session cookies.

In either case, maintain your own `User`, `Business`, and `BusinessMember` records in Postgres.

---

## 11. Route and Page Plan

### Public Marketing

```txt
/                 Landing page
/pricing          Pricing
/faq              FAQ
/sign-in          Sign in
/sign-up          Sign up
```

### Customer-Facing Public Confirmation

```txt
/confirm/[token]  Customer confirms appointment, accepts policy, opts in, pays deposit
/pay/success      Stripe success redirect
/pay/cancel       Stripe cancel redirect
```

No login required for customer confirmation page.

### Business Dashboard

```txt
/app/dashboard
/app/booking-holds
/app/booking-holds/new
/app/booking-holds/[id]
/app/bookings
/app/calendar
/app/services
/app/policies
/app/providers
/app/customers
/app/customers/[id]
/app/payments
/app/waitlist
/app/analytics
/app/settings
```

### API Route Handlers

```txt
POST /api/booking-holds
GET  /api/booking-holds/[id]
PATCH /api/booking-holds/[id]
POST /api/booking-holds/[id]/checkout
POST /api/webhooks/stripe
POST /api/webhooks/twilio
POST /api/webhooks/sendgrid
GET  /api/health
```

### Server Actions

Use Server Actions for dashboard forms:

- create booking hold
- update service
- update policy
- create provider
- update settings
- mark appointment completed
- mark appointment no-show
- cancel appointment

Use Route Handlers for:

- webhooks
- Stripe Checkout Session creation
- public token-based flows
- third-party callbacks

---

## 12. UI Component Plan With shadcn/ui

Use shadcn/ui components as local source-controlled components.

Initial components:

- `Button`
- `Card`
- `Input`
- `Label`
- `Textarea`
- `Select`
- `Checkbox`
- `Dialog`
- `DropdownMenu`
- `Tabs`
- `Table`
- `Badge`
- `Alert`
- `Form`
- `Sheet`
- `Separator`
- `Calendar`
- `Popover`
- `Command`
- `Sonner` or `Toast`

Key custom components:

```txt
components/dashboard/AppSidebar.tsx
components/dashboard/KpiCard.tsx
components/booking-holds/CreateBookingHoldForm.tsx
components/booking-holds/BookingHoldStatusTimeline.tsx
components/booking-holds/ConfirmationLinkBox.tsx
components/customers/CustomerReliabilityCard.tsx
components/payments/PaymentStatusBadge.tsx
components/shared/Money.tsx
components/shared/DateTime.tsx
components/shared/EmptyState.tsx
components/shared/LoadingButton.tsx
```

Design rules:

- Mobile-first customer pages
- Desktop-first dashboard, responsive enough for mobile quick actions
- Keep confirmation page extremely simple
- Minimize JavaScript by using Server Components for read-heavy pages
- Use Client Components only for forms, modals, dropdowns, and interactive calendars

---

## 13. Main Workflows

## 13.1 Business Onboarding

```txt
Business owner signs up
→ creates business profile
→ creates first service
→ creates cancellation policy
→ connects Stripe account
→ creates first booking hold
```

Implementation tasks:

1. Create business record
2. Create owner membership
3. Create default policy template
4. Create default service templates by vertical if selected
5. Create Stripe connected account
6. Redirect to Stripe onboarding

---

## 13.2 Create Booking Hold

Business form fields:

```txt
Client name
Client email optional
Client phone optional
Client Instagram/social handle optional
Service
Provider/staff optional
Date
Start time
Duration
Deposit amount
Estimated total optional
Policy template
Internal notes
```

Flow:

```txt
Business creates hold
→ app creates BookingHold with token
→ app shows confirmation link
→ business manually sends link to client through DM/text/email
```

Important: the app should not send SMS to a client just because the business typed a phone number. The client must opt in on the confirmation page before automated SMS is sent.

---

## 13.3 Client Confirmation Page

Customer opens:

```txt
/confirm/[token]
```

Page sections:

1. Appointment summary
2. Business/provider info
3. Deposit amount
4. Cancellation/no-show policy
5. Policy acceptance checkbox
6. SMS opt-in checkbox
7. Email opt-in checkbox
8. Payment button

When customer submits:

```txt
validate token
→ create or update Customer
→ store PolicyAcceptance
→ store SmsConsent if opted in
→ create Stripe Checkout Session
→ redirect customer to Stripe Checkout
```

---

## 13.4 Stripe Checkout + Webhook

Use Stripe Checkout for MVP.

Flow:

```txt
Customer pays deposit in Stripe Checkout
→ Stripe redirects to success page
→ Stripe webhook sends checkout.session.completed
→ app verifies webhook signature
→ app marks payment succeeded
→ app creates confirmed Appointment
→ app marks BookingHold confirmed
→ app schedules reminders
→ app sends confirmation email
→ app sends confirmation SMS only if SMS consent exists
```

Idempotency requirements:

- Store Stripe Checkout Session ID
- Store Payment Intent ID
- Webhook handler must be idempotent
- Use Redis lock or database uniqueness to avoid duplicate appointments

---

## 13.5 Reminders

Use BullMQ jobs.

Default reminder schedule:

- immediately after confirmation: confirmation email/SMS
- 72 hours before: reminder
- 24 hours before: confirmation request
- 4 hours before: final reminder
- 15 minutes after start time: no-show check prompt to business

Reminder job payload:

```ts
type ReminderJob = {
  appointmentId: string;
  channel: "SMS" | "EMAIL";
  reminderType: "CONFIRMATION" | "REMINDER_72H" | "CONFIRM_24H" | "FINAL_4H" | "NO_SHOW_CHECK";
};
```

Before sending SMS:

1. Load appointment
2. Load customer
3. Check active SMS consent for this business/customer/phone/scope
4. If no consent, do not send SMS
5. Log skipped reminder

---

## 13.6 Cancellation and Late Cancellation

Customer clicks cancel link or business cancels appointment.

Flow:

```txt
calculate hours until start
→ compare with policy cancellation window
→ if early cancellation, allow refund workflow
→ if late cancellation, mark LATE_CANCELLED and keep deposit by default
→ optionally trigger waitlist refill
```

MVP can make refunds manual from dashboard. Later automate refund rules.

---

## 13.7 No-Show Handling

Business appointment detail page should have buttons:

```txt
Mark Complete
Mark No-Show
Cancel
Reschedule
```

When marked no-show:

```txt
appointment.status = NO_SHOW
customer.noShowCount += 1
depositStatus = FORFEITED if policy says keep deposit
create audit event
send optional email notice
```

Do not automatically charge new fees in MVP. Start with deposit forfeit only.

---

## 13.8 Waitlist and Refill Later

Flow:

```txt
appointment cancelled
→ find waitlist entries matching service/provider/time
→ offer slot to first customer
→ hold slot for 15-20 minutes
→ if customer claims and pays deposit, confirm appointment
→ if not claimed, offer next customer
```

This should be phase 2, not day-one MVP.

---

## 14. SMS and Email Rules

### SMS Consent Rule

A phone number entered by the business is contact information only. It is not consent.

Your code should enforce:

```ts
if (!activeSmsConsent) {
  throw new Error("Cannot send SMS without active consent");
}
```

SMS consent can be captured only through:

- confirmation page checkbox
- customer booking form checkbox
- waitlist form checkbox
- explicit opt-in page

Store the exact consent text snapshot.

### Required SMS Footer/Opt-Out Behavior

Every SMS flow should support STOP/START.

Inbound Twilio webhook should:

- parse inbound message
- if STOP, revoke active consent for that phone/business where applicable
- if START, reactivate if legally allowed and tied to prior consent
- log inbound message

### Email

Use SendGrid for transactional email.

Email types:

- confirmation link email
- deposit paid receipt
- appointment confirmed
- reminder
- cancellation
- refund notification
- no-show notice

Email can be used more broadly than SMS, but still include unsubscribe management for non-transactional messages. Keep appointment confirmation/reminder emails transactional.

---

## 15. Stripe Connect Plan

Each business should connect its own Stripe account.

MVP payment model:

```txt
Customer pays deposit
→ Stripe processes payment for connected business account
→ platform takes application fee
→ business receives payout through Stripe
```

Use direct charges or destination charges depending on final Stripe setup.

For a SaaS where the business is the merchant of record, prefer direct charges if the connected-account flow fits the region/account type.

Store on Business:

```txt
stripeConnectedAccountId
stripeChargesEnabled
stripePayoutsEnabled
```

Do not allow a business to collect deposits until Stripe onboarding is complete enough for charges.

---

## 16. Redis Usage

Use Redis for:

1. BullMQ queues
2. short-lived idempotency locks
3. rate limiting public token endpoints
4. dashboard KPI cache
5. webhook processing locks

Example keys:

```txt
lock:stripe-webhook:{eventId}
lock:booking-hold-confirm:{holdId}
rate:confirm-token:{ip}:{token}
kpi:business:{businessId}:dashboard:{dateRange}
```

---

## 17. Background Job Queues

Create queues:

```txt
notifications
reminders
hold-expiration
waitlist-refill
email
sms
```

Files:

```txt
lib/queues.ts
worker/index.ts
worker/processors/reminders.ts
worker/processors/email.ts
worker/processors/sms.ts
worker/processors/hold-expiration.ts
```

Queue examples:

```ts
import { Queue } from "bullmq";
import { redisConnection } from "@/lib/redis";

export const remindersQueue = new Queue("reminders", {
  connection: redisConnection,
});
```

Worker example:

```ts
import { Worker } from "bullmq";
import { redisConnection } from "../lib/redis";

new Worker(
  "reminders",
  async (job) => {
    // process reminder job
  },
  { connection: redisConnection }
);
```

---

## 18. Validation and Security

Use Zod for every input boundary:

- Server Actions
- Route Handlers
- webhook payload interpretation after signature verification
- public confirmation form

Security checklist:

- Verify Stripe webhook signatures
- Verify Twilio webhook signatures if possible
- Rate-limit `/confirm/[token]` actions
- Never trust `businessId` from client without checking membership
- Use tokenized booking hold URLs with unguessable IDs
- Expire booking holds if not confirmed
- Store policy text snapshot
- Store consent text snapshot
- Keep audit logs for payment/status changes
- Use HttpOnly secure cookies for sessions
- Do not expose PII in logs
- Do not send SMS without consent

---

## 19. Vertical Templates

During onboarding, ask:

```txt
What type of business are you?
- Tattoo / piercing
- Hair salon
- Nail salon
- Spa / massage
- Med spa
- Barber
- Lash / brow
- Tutor / coach
- Photography
- Other service business
```

Then create starter service and policy templates.

### Tattoo Template

Services:

- Consultation
- Small tattoo session
- Half-day session
- Full-day session

Extra fields later:

- placement
- size
- style
- reference images
- cover-up yes/no

### Nail Salon Template

Services:

- Manicure
- Gel manicure
- Acrylic full set
- Fill
- Pedicure

Extra fields later:

- desired style
- add-ons
- allergies
- preferred tech

### Hair Salon Template

Services:

- Haircut
- Hair color
- Highlights
- Balayage
- Blowout

Extra fields later:

- hair length
- color history
- desired result
- reference images

### Spa / Massage Template

Services:

- Facial
- Massage
- Deep tissue massage
- Body treatment

Extra fields later:

- contraindications
- allergies
- pressure preference

### Med Spa Template

Services:

- Consultation
- Botox consultation
- Laser consultation
- Facial treatment

Extra fields later:

- medical disclaimers
- contraindications
- consent forms

MVP can store these as service names and policy templates only. Custom intake fields can come later.

---

## 20. Pricing Implementation

Plan model:

```txt
Starter: $0/mo + 3% platform fee
Pro: $29/mo + 1% platform fee
Studio: $79/mo + 0.75% platform fee
Business: $149/mo + 0.5% platform fee
```

Implement plan limits later. For MVP, store plan and fee basis points.

```prisma
model SubscriptionPlan {
  id              String @id @default(cuid())
  businessId      String @unique
  plan            String
  platformFeeBps  Int
  monthlyPriceCents Int
  status          String
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
}
```

For MVP, billing subscriptions can be manual or Stripe Billing later. Deposit collection is more important than SaaS subscription billing in the first prototype.

---

## 21. Dashboard KPIs

Main dashboard cards:

- Upcoming appointments
- Awaiting deposits
- Confirmed appointments
- No-shows in last 30 days
- Revenue secured through deposits
- Deposit conversion rate
- Late cancellations

Analytics formulas:

```txt
Deposit conversion rate = confirmed booking holds / created booking holds
No-show rate = no-show appointments / completed + no-show appointments
Late cancellation rate = late-cancelled appointments / confirmed appointments
Protected revenue = sum of paid deposits
```

---

## 22. MVP Build Milestones

### Milestone 1 — Foundation

- Next.js app initialized
- Tailwind configured
- shadcn/ui configured
- Prisma configured
- Postgres connection working
- Redis connection working
- Basic auth working
- Dashboard shell and sidebar

### Milestone 2 — Business Setup

- Business profile
- Services CRUD
- Policy templates CRUD
- Providers CRUD
- Stripe Connect onboarding placeholder or real onboarding

### Milestone 3 — Booking Hold Flow

- Create booking hold form
- Booking hold detail page
- Tokenized confirmation URL
- Expiration support
- Customer confirmation page

### Milestone 4 — Deposit Payment

- Stripe Checkout Session creation
- Stripe webhook handler
- Payment ledger
- Confirm appointment after payment
- Success/cancel pages

### Milestone 5 — Notifications

- SendGrid transactional email
- Twilio SMS after consent
- SMS consent storage
- Reminder jobs with BullMQ
- Worker deployment

### Milestone 6 — Appointment Management

- Upcoming appointments list
- Mark complete
- Mark no-show
- Cancel appointment
- Deposit status updates
- Customer profile history

### Milestone 7 — Polish

- Dashboard KPIs
- Mobile customer confirmation page polish
- Error states
- Empty states
- Loading states
- Audit logs
- Seed data

### Milestone 8 — Phase 2

- Waitlist
- Refill automation
- Calendar sync
- Intake forms
- Staff permissions
- Stripe Billing subscriptions

---

## 23. Suggested Codex Tasks

Give Codex tasks in small chunks.

### Task 1

Initialize Next.js TypeScript app with Tailwind and shadcn/ui. Create dashboard layout with sidebar and placeholder pages.

### Task 2

Add Prisma schema for businesses, users, services, policies, providers, booking holds, customers, appointments, payments, consents, and reminders. Add seed data.

### Task 3

Build services CRUD and policy templates CRUD using Server Actions and Zod validation.

### Task 4

Build providers/staff CRUD.

### Task 5

Build Create Booking Hold form and booking hold detail page.

### Task 6

Build public `/confirm/[token]` page. It should collect customer details, policy acceptance, SMS/email opt-in, and start Stripe Checkout.

### Task 7

Add Stripe Checkout Session route and Stripe webhook fulfillment. Make webhook idempotent.

### Task 8

Add SendGrid email service and Twilio SMS service. Enforce SMS consent before sending.

### Task 9

Add BullMQ worker for reminders and hold expiration.

### Task 10

Build customer list/detail and appointment status management.

---

## 24. Important Engineering Rules

1. Never send SMS without stored active consent.
2. Never mark appointment confirmed until payment webhook succeeds if deposit is required.
3. Never rely only on Stripe redirect success page; webhook is the source of truth.
4. Never store only the policy ID; store a policy text snapshot for every acceptance.
5. Keep business-entered customer phone number separate from SMS consent.
6. Use database transactions when confirming booking holds.
7. Use idempotency locks for payment webhooks.
8. Use tokenized public URLs, not numeric IDs.
9. Do not build native mobile app in MVP.
10. Do not build full ticketing in MVP.

---

## 25. Final Recommended Stack Snapshot

```txt
App: Next.js App Router
Language: TypeScript
UI: Tailwind CSS + shadcn/ui
Database: PostgreSQL
ORM: Prisma
Cache/Queue: Redis + BullMQ
Payments: Stripe Connect + Stripe Checkout
SMS: Twilio Programmable Messaging
Email: Twilio SendGrid
Validation: Zod
Forms: React Hook Form + shadcn/ui Form
Deployment: Vercel/Railway/Render/Fly + separate worker
```


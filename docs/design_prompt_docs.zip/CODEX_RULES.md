# CODEX_RULES.md

These rules are mandatory for all Codex agents and human contributors working on this repository.

## 1. Product Scope Rules

The MVP is an appointment commitment SaaS for service businesses.

Build first:

```text
booking holds
confirmation links
policy acceptance
deposit collection
SMS/email consent capture
email/SMS reminders
appointment status tracking
basic customer/payment dashboard
```

Do not build first:

```text
native mobile app
full event-ticketing platform
seating charts
QR ticket scanning
AI receptionist
Instagram DM automation
full POS system
complex marketplace payouts
```

Event/class/ticketing mode can be a later module. Appointment mode comes first.

---

## 2. Stack Rules

Use:

```text
Next.js App Router
TypeScript
Tailwind CSS
shadcn/ui
PostgreSQL
Prisma
Redis
BullMQ
Stripe
Twilio SMS
Twilio SendGrid Email
Zod
React Hook Form
```

Do not introduce a new major framework, ORM, UI kit, or backend language without explicit approval.

---

## 3. SMS Consent Rules

These rules are non-negotiable.

1. A phone number is not SMS consent.
2. A business typing or pasting a phone number does not allow the platform to text the customer.
3. SMS can only be sent after the customer explicitly opts in through a customer-facing flow or another approved consent source.
4. Consent must be stored in the database.
5. Consent must include the consent text/version, source, timestamp, phone number, customer, and business.
6. STOP/opt-out must be honored.
7. If consent is missing or revoked, message status should become `SKIPPED_NO_CONSENT`, not sent.
8. Appointment reminders are allowed only within the consent scope.
9. Do not implement marketing SMS in MVP.

Required helper behavior:

```ts
canSendSms(businessId, customerId, phone, scope) -> boolean
sendSms(...) must call canSendSms(...) before sending
```

Never bypass this guard.

---

## 4. Email Rules

Email can be used for transactional appointment communications.

Store `MessageLog` rows for important email sends:

- confirmation email
- deposit receipt email
- reminder email
- cancellation/reschedule email
- failed payment email

Do not implement bulk marketing email in MVP.

---

## 5. Payment Rules

Stripe is the payment processor.

1. Never store raw card numbers.
2. Never trust client-side payment success.
3. Stripe webhooks are the source of truth.
4. Verify Stripe webhook signatures.
5. Make webhook handling idempotent.
6. Store Stripe event IDs that have been processed.
7. Use Prisma transactions when updating payment + booking/appointment state.
8. Use Stripe test mode in local/staging.
9. Keep application/platform fees configurable by environment.
10. Do not implement complex escrow/custody behavior in MVP.

For deposit-required booking holds:

```text
BookingHold can become confirmed only after verified payment webhook succeeds.
```

For non-deposit booking holds:

```text
BookingHold can become confirmed after policy acceptance and required contact/consent steps are complete.
```

---

## 6. Policy Acceptance Rules

Every policy acceptance must store an immutable snapshot.

Required fields:

```text
businessId
customerId
bookingHoldId or appointmentId
policyTemplateId if available
policyTitle
policyText snapshot
policyVersion
acceptedAt
ipAddress if available
userAgent if available
```

Do not store only `policyTemplateId`; policy text may change later.

---

## 7. Public Token Rules

Public confirmation URLs must use secure random tokens.

Rules:

1. Do not expose numeric sequential IDs in public URLs.
2. Tokens must be long, random, and unguessable.
3. Tokens must expire or be invalidated when no longer needed.
4. Rate limit token lookup endpoints.
5. Do not leak whether a token belongs to another business.
6. If token is invalid/expired, show a generic friendly error.

Recommended route:

```text
/confirm/[token]
```

---

## 8. Multi-Tenant Authorization Rules

Most data is scoped by `businessId`.

Every server action, API route, and database query for dashboard users must verify that the authenticated user belongs to the target business.

Never rely on client-provided `businessId` alone.

Bad:

```ts
await prisma.bookingHold.findMany({ where: { businessId: input.businessId } })
```

Better:

```ts
const businessId = await requireCurrentBusinessId()
await prisma.bookingHold.findMany({ where: { businessId } })
```

Public token routes may access data by token, but should return only the minimum customer-facing appointment information.

---

## 9. Data Model Rules

Use consistent domain objects:

```text
Business
User
Provider
Service
PolicyTemplate
Customer
BookingHold
Appointment
PolicyAcceptance
SmsConsent
Payment
MessageLog
WaitlistEntry
AuditLog
ProcessedWebhookEvent
```

Use enums for important statuses. Avoid ad-hoc strings spread throughout the codebase.

Add indexes for:

```text
businessId
customerId
providerId
serviceId
status
startTime
confirmationToken
stripePaymentIntentId
stripeCheckoutSessionId
stripeEventId
phone
email
```

---

## 10. State Transition Rules

BookingHold states:

```text
HOLD_CREATED
AWAITING_CONFIRMATION
AWAITING_PAYMENT
CONFIRMED
EXPIRED
CANCELLED
```

Appointment states:

```text
CONFIRMED
CONFIRMATION_REQUESTED
AT_RISK
COMPLETED
CANCELLED
NO_SHOW
```

Payment states:

```text
PENDING
PROCESSING
SUCCEEDED
FAILED
REFUNDED
PARTIALLY_REFUNDED
DISPUTED
FORFEITED
```

Message states:

```text
QUEUED
SENT
DELIVERED
FAILED
SKIPPED_NO_CONSENT
OPTED_OUT
```

All state transitions that affect money, appointment confirmation, consent, or policy acceptance should create `AuditLog` entries.

---

## 11. Next.js Rules

Use the App Router.

Recommended structure:

```text
src/app/(marketing)/page.tsx
src/app/(auth)/sign-in/page.tsx
src/app/(app)/dashboard/page.tsx
src/app/(app)/booking-holds/page.tsx
src/app/(app)/booking-holds/new/page.tsx
src/app/(app)/booking-holds/[id]/page.tsx
src/app/confirm/[token]/page.tsx
src/app/api/stripe/webhook/route.ts
src/app/api/twilio/webhook/route.ts
src/app/api/jobs/route.ts if needed
src/components/*
src/lib/*
src/server/*
src/workers/*
```

Server/client component rules:

- Use Server Components for data-fetching pages.
- Use Client Components for forms, dialogs, and interactive controls.
- Do not import server-only code into Client Components.
- Do not expose secrets through `NEXT_PUBLIC_*` unless truly public.

---

## 12. Validation Rules

All external input must be validated with Zod.

Validate:

- server action inputs
- API route request bodies
- webhook payloads where practical
- public confirmation forms
- booking hold forms
- service/policy/provider forms

Return safe user-facing errors. Log detailed errors server-side only.

---

## 13. Background Job Rules

Use Redis + BullMQ for:

- hold expiration
- appointment reminders
- retryable email/SMS sends
- waitlist refill later
- cleanup jobs

Do not run long-lived workers inside serverless request handlers.

Workers should be started as a separate process:

```bash
npm run worker
```

Jobs should be idempotent. A duplicate reminder job should not send duplicate messages without checking current state and previous logs.

---

## 14. Reminder Rules

Before sending a reminder:

1. Load appointment fresh from database.
2. Verify appointment is still active.
3. Verify reminder has not already been sent for the same appointment/template/time bucket.
4. For SMS, verify active consent.
5. Write `MessageLog`.
6. Send message.
7. Update `MessageLog` status.

If no SMS consent exists, do not fail the whole job. Mark SMS as skipped and send email if available.

---

## 15. Refund and Forfeit Rules

MVP can keep refund handling simple, but must be explicit.

Supported MVP states:

```text
refund_not_required
refund_needed
refund_requested
refunded
forfeited
```

Do not silently refund or forfeit without recording an audit log.

If actual Stripe refunds are implemented:

- call Stripe server-side only
- record refund ID
- update payment ledger
- create audit log

---

## 16. UI Rules

Use shadcn/ui and Tailwind.

Customer-facing confirmation pages must be mobile-first.

Dashboard pages should be responsive but can prioritize desktop layout.

Required UI states:

- loading
- empty
- error
- disabled/submitting
- success
- expired token
- already confirmed
- payment pending
- payment success
- payment failed

Avoid fake polish that hides missing functionality. Make placeholders clear.

---

## 17. Testing Rules

Add tests for business-critical logic.

Prioritize tests for:

- SMS consent guard
- booking hold state transitions
- policy acceptance creation
- Stripe webhook idempotency
- payment-to-appointment confirmation transaction
- public token expiration
- tenant authorization helpers

Run before finishing:

```bash
npm run lint
npm run typecheck
npm test
npx prisma validate
```

If a command fails, report the exact failure and do not pretend it passed.

---

## 18. Environment Variable Rules

Use `.env.example` and server-side env validation.

Expected variables:

```text
DATABASE_URL
REDIS_URL
NEXTAUTH_SECRET or AUTH_SECRET
NEXT_PUBLIC_APP_URL
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
STRIPE_CONNECT_CLIENT_ID
STRIPE_PLATFORM_FEE_PERCENT
TWILIO_ACCOUNT_SID
TWILIO_AUTH_TOKEN
TWILIO_MESSAGING_SERVICE_SID
SENDGRID_API_KEY
SENDGRID_FROM_EMAIL
```

Do not commit real secrets.

Do not log secrets.

---

## 19. Git and Codex Workflow Rules

For multi-agent work:

- use one Git worktree per agent
- use one feature branch per task
- avoid overlapping file ownership
- merge into `develop`, not directly into `main`
- run integration QA after several merges

Codex agents must not run:

```bash
git reset --hard
git clean -fd
git push --force
rm -rf
prisma migrate reset
DROP DATABASE
```

unless the human owner explicitly requests it.

---

## 20. Done Response Format for Codex Agents

Every Codex task should finish with:

```text
Summary:
- ...

Changed files:
- ...

Commands run:
- ...

Migrations/env vars:
- ...

Risks / follow-up:
- ...
```

Be honest if something was not run or did not pass.

